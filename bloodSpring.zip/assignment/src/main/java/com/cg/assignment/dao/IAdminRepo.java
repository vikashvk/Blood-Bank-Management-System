package com.cg.assignment.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cg.assignment.model.Admin;

public interface IAdminRepo extends MongoRepository<Admin, String>{

}
