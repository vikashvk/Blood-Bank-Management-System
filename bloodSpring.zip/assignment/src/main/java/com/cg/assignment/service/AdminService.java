package com.cg.assignment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.assignment.dao.IAdminRepo;
import com.cg.assignment.model.Admin;

@Service
public class AdminService {
	
	@Autowired
	IAdminRepo iAdminRepo;

	public AdminService() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void create(Admin a) {
		iAdminRepo.save(a);
	}

	public Admin searchById(String adminName) {
		
		return iAdminRepo.findById(adminName).orElse(null);
	}
	
}
