package com.cg.assignment.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.assignment.model.Admin;
import com.cg.assignment.model.Donor;
import com.cg.assignment.model.Patient;
import com.cg.assignment.service.AdminService;
import com.cg.assignment.service.DonorService;
import com.cg.assignment.service.PatientService;
import com.cg.assignment.service.SMSService;

@Controller
public class BloodController {

	@Autowired
	PatientService patientService;
	@Autowired
	DonorService donorService;
	@Autowired
	AdminService adminService;
	@Autowired
	org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

	@RequestMapping("/")
	public String welcome(@ModelAttribute("admin") Admin a) {

		return "login";
	}

	@RequestMapping("/logout")
	public String logout(@ModelAttribute("admin") Admin a) {

		return "login";
	}

	@RequestMapping("/menu")
	public String index(@ModelAttribute("admin") Admin admin, @ModelAttribute("p") Patient p, Model m,
			HttpSession httpSession) {
		Admin a = adminService.searchById(admin.getAdminName());

		if (a != null) {
			if (passwordEncoder.matches(admin.getPassword(), a.getPassword())) {
				return "menu";

			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "login";
			}

		} else {
			m.addAttribute("msg", "OMG! Admin don't Exist.");

		}

		return "login";
	}

	@RequestMapping(value = "/patientList", method = RequestMethod.GET)
	public String getPatient(ModelMap m) {

		List<Patient> patientList = patientService.getAllPatient();
		m.addAttribute("patientList", patientList);
		return "patientList";

	}

	@RequestMapping("/add")
	public String addPatient(@ModelAttribute("p") Patient p) {
		return "add";
	}

	@RequestMapping(value = "/donorList", method = RequestMethod.POST)
	public String locateDonor(@ModelAttribute("p") Patient p, Model m) {
		patientService.create(p);
		System.out.println(p);
		List<Donor> donor = new ArrayList<Donor>();
		SMSService smsservice = new SMSService();
		for (Donor d : donorService.getAllDonors()) {
			if (p.getBloodGroup().equalsIgnoreCase(d.getBloodGroup())) {
				donor.add(d);
				smsservice.sendSms(p.getPhoneNum(), "Hi! " + p.getPatientName() + " Your donor is " + d.getName()
						+ ".Please contact him on this " + d.getPhNum());
			}
		}
		m.addAttribute("donorList", donor);
		return "donorList";
	}
	@RequestMapping(value = "/donors", method = RequestMethod.GET)
	public String getDonor(ModelMap m) {

		List<Donor> donorList = donorService.getAllDonors();
		m.addAttribute("donorList", donorList);
		return "donorList";

	}

}
