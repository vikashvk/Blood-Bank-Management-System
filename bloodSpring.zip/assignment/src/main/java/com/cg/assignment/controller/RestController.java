package com.cg.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.assignment.dao.IDonorRepo;
import com.cg.assignment.dao.IPatientRepo;
import com.cg.assignment.model.Admin;
import com.cg.assignment.model.Donor;
import com.cg.assignment.model.DonorLocation;
import com.cg.assignment.model.Patient;
import com.cg.assignment.service.AdminService;

@RequestMapping("/cg/blood")
@org.springframework.web.bind.annotation.RestController
public class RestController {
	@Autowired
	private IPatientRepo iPatientRepo;
	@Autowired
	private IDonorRepo iDonorRepo;
	@Autowired
	AdminService adminService;
	@Autowired
	PasswordEncoder passwordEncoder;

	@GetMapping("/parse")
	public List<Patient> getAllPatient() {
		return iPatientRepo.findAll();
	}

	@PostMapping(path = "/consume", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> getAllDonors(
			@RequestBody Donor donor) throws Exception {
			iDonorRepo.save(donor);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PostMapping("/create")
	public void Create() {
		Admin a = new Admin("admin",passwordEncoder.encode("abcd"));
		adminService.create(a);

	}

}
