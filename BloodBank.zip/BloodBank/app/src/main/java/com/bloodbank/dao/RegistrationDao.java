package com.bloodbank.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.bloodbank.model.Donor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by v2 on 9/21/2019.
 */

public class RegistrationDao extends SQLiteOpenHelper {
    public RegistrationDao(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Bank.db";
    private static final String TABLE_REGISTER= "donor";

//    public static final String KEY_ID = "uId";
    public static final String KEY_NAME = " name";
    public static final String KEY_PHONE_NUM = "phNum";
    public static final String KEY_EMAIL_ID="email_id";
    public static final String KEY_PASSWORD = "pwd";
    public static final String KEY_REPASSWORD = "rePwd";
    public static final String KEY_BLOOD_GROUP = "bloodGroup";

    public static final String CREATE_TABLE="CREATE TABLE " + TABLE_REGISTER + "("
             + KEY_NAME + " TEXT,"+KEY_PHONE_NUM + " TEXT,"+KEY_EMAIL_ID+ " TEXT PRIMARY KEY,"
            + KEY_PASSWORD + " TEXT, " + KEY_REPASSWORD + " TEXT, " +KEY_BLOOD_GROUP + " TEXT " + ")";

    @Override
    public void onCreate(SQLiteDatabase db) {

            db.execSQL(CREATE_TABLE);
            // Database does not exist so copy it from assets here
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REGISTER);
        onCreate(db);
    }
    public void addDetails(Donor donor){
        SQLiteDatabase  db=this.getWritableDatabase();
        ContentValues values=new ContentValues();
//        values.put(KEY_ID,donor.getuId());
        values.put(KEY_NAME,donor.getName());
        values.put(KEY_PHONE_NUM,donor.getPhNum());
        values.put(KEY_EMAIL_ID,donor.geteMail());
        values.put(KEY_PASSWORD,donor.getPwd());
        values.put(KEY_REPASSWORD,donor.getRePwd());
        values.put(KEY_BLOOD_GROUP,donor.getBloodGroup());

        db.insert(TABLE_REGISTER,null,values);
        db.close();
    }
    public List<Donor> getAllDonor() {
        String[] columns = {
                KEY_NAME,
                KEY_PHONE_NUM,
                KEY_EMAIL_ID,
                KEY_PASSWORD,KEY_REPASSWORD,KEY_BLOOD_GROUP
        };

        String sortOrder =
                KEY_NAME + " ASC";
        List<Donor> donorList = new ArrayList<Donor>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_REGISTER,
                columns,
                null,
                null,
                null,
                null,
                sortOrder);

        if (cursor.moveToFirst()) {
            do {
                Donor donor = new Donor();
//                donor.setuId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_ID))));
                donor.setName(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                donor.setPhNum(cursor.getString(cursor.getColumnIndex(KEY_PHONE_NUM)));
                donor.seteMail(cursor.getString(cursor.getColumnIndex(KEY_EMAIL_ID)));
                donor.setPwd(cursor.getString(cursor.getColumnIndex(KEY_PASSWORD)));
                donor.setRePwd(cursor.getString(cursor.getColumnIndex(KEY_REPASSWORD)));
                donor.setBloodGroup(cursor.getString(cursor.getColumnIndex(KEY_BLOOD_GROUP)));
                donorList.add(donor);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();


        return donorList;
    }

    /**
     * This method to update donor record
     *
     * @param donor
     */
    public void updateDonor(Donor donor) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, donor.getName());
        values.put(KEY_EMAIL_ID, donor.geteMail());
        values.put(KEY_PASSWORD, donor.getPwd());

        // updating row
        db.update(TABLE_REGISTER, values, KEY_EMAIL_ID + " = ?",
                new String[]{String.valueOf(donor.geteMail())});
        db.close();
    }

    /**
     * This method is to delete donor record
     *
     * @param donor
     */
    public void deleteDonor(Donor donor) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_REGISTER, KEY_EMAIL_ID + " = ?",
                new String[]{String.valueOf(donor.geteMail())});
        db.close();
    }

    /**
     * This method to check donor exist or not
     *
     * @param email
     * @return true/false
     */
    public boolean checkDonor(String email) {


        String[] columns = {
                KEY_EMAIL_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = KEY_EMAIL_ID + " = ?";
        String[] selectionArgs = {email};

        Cursor cursor = db.query(TABLE_REGISTER,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkDonor(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                KEY_EMAIL_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = KEY_EMAIL_ID + " = ?" + " AND " + KEY_PASSWORD + " = ?";


        String[] selectionArgs = {email, password};

        Cursor cursor = db.query(TABLE_REGISTER,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }
}