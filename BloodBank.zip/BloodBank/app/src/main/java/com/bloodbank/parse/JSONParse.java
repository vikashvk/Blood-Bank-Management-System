package com.bloodbank.parse;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.bloodbank.bloodbank.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class JSONParse extends AppCompatActivity {

    ListView listView;

    String apiUrl = "http://10.0.2.2:8082/cg/blood/parse";
    ProgressDialog progressDialog;
    String patientId, patientName, bloodGroup;
    ArrayList<HashMap<String, String>> patientList;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.json_list);
        patientList=new ArrayList<>();
        listView = (ListView) findViewById(R.id.listView);
        jsonParse(apiUrl);

    }

    private void jsonParse(final String apiUrl) {
        class MyAsyncTasks extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(JSONParse.this);
                progressDialog.setMessage("Loading Blesses");
                progressDialog.setCanceledOnTouchOutside(true);
                progressDialog.show();
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(apiUrl);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String str) {
                super.onPostExecute(str);
                Log.d("data ", str);
                progressDialog.dismiss();
                try {
                    JSONArray jsonArray = new JSONArray(str);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        String id = obj.getString("patientId");
                        String name = obj.getString("patientName");
                        String bloodGroup = obj.getString("bloodGroup");
                        String phoneNum = obj.getString("phoneNum");

                        JSONObject loc=obj.getJSONObject("hospitalLocation");
                        String hLat = loc.getString("hospitalLat");
                        String hLong = loc.getString("hospitalLong");


                        HashMap<String, String> patient = new HashMap<>();
                        patient.put("patientId",id);
                        patient.put("patientName",name);
                        patient.put("bloodGroup",bloodGroup);
                        patient.put("phoneNum",phoneNum);
                        patient.put("hospitalLat",hLat);
                        patient.put("hospitalLong",hLong);

                        patientList.add(patient);

                    }
                    ListAdapter adapter = new SimpleAdapter(JSONParse.this,patientList, R.layout.list_item, new String[]{"patientName", "bloodGroup",
                            "phoneNum","hospitalLat","hospitalLong"},new int[]{R.id.jsonName,
                            R.id.jsonBloodGroup, R.id.jsonMobile,R.id.jsonLat,R.id.jsonLong});
                    listView.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        MyAsyncTasks getJSON = new MyAsyncTasks();
        getJSON.execute();
    }
}