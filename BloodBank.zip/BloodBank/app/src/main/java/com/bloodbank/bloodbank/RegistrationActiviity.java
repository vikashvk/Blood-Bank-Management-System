package com.bloodbank.bloodbank;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.widget.Spinner;

import com.bloodbank.dao.RegistrationDao;
import com.bloodbank.model.Donor;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by v2 on 9/21/2019.
 */

public class RegistrationActiviity extends AppCompatActivity implements View.OnClickListener{

    private static final String TAG = "RegistrationActiviity";
    private final AppCompatActivity activity = RegistrationActiviity.this;
    public String apiURL="http://10.0.2.2:8082/cg/blood/consume";
    private NestedScrollView nestedScrollView;

    private TextInputLayout textInputLayoutName;
    private TextInputLayout textInputLayoutNumber;
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPassword;
    private TextInputLayout textInputLayoutConfirmPassword;

    private TextInputEditText textInputEditTextName;
    private TextInputEditText textInputEditTextPhoneNumber;
    private TextInputEditText textInputEditTextEmail;
    private TextInputEditText textInputEditTextPassword;
    private TextInputEditText textInputEditTextConfirmPassword;
    private Spinner bloodGrp;

    private AppCompatButton appCompatButtonRegister;
    private AppCompatTextView appCompatTextViewLoginLink;

    private InputValidation inputValidation;
    private RegistrationDao registrationDao;
    private Donor donor;
    ProgressDialog progressDialog;
    String name,userId,phoneNumber;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        getSupportActionBar().hide();

        initViews();
        initListeners();
        initObjects();
    }

    private void initViews() {
        nestedScrollView = (NestedScrollView) findViewById(R.id.nestedScrollView);

        textInputLayoutName = (TextInputLayout) findViewById(R.id.textInputLayoutName);
        textInputLayoutNumber = (TextInputLayout) findViewById(R.id.textInputLayoutPhoneNumber);
        textInputLayoutEmail = (TextInputLayout) findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPassword = (TextInputLayout) findViewById(R.id.textInputLayoutPassword);
        textInputLayoutConfirmPassword = (TextInputLayout) findViewById(R.id.textInputLayoutConfirmPassword);

        textInputEditTextName = (TextInputEditText) findViewById(R.id.textInputEditTextName);
        textInputEditTextPhoneNumber = (TextInputEditText) findViewById(R.id.textInputEditTextPhoneNumber);
        textInputEditTextEmail = (TextInputEditText) findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPassword = (TextInputEditText) findViewById(R.id.textInputEditTextPassword);
        textInputEditTextConfirmPassword = (TextInputEditText) findViewById(R.id.textInputEditTextConfirmPassword);
        bloodGrp = (Spinner) findViewById(R.id.txtBlood);

        appCompatButtonRegister = (AppCompatButton) findViewById(R.id.appCompatButtonRegister);

        appCompatTextViewLoginLink = (AppCompatTextView) findViewById(R.id.appCompatTextViewLoginLink);

    }

    /**
     * This method is to initialize listeners
     */
    private void initListeners() {
        appCompatButtonRegister.setOnClickListener(this);
        appCompatTextViewLoginLink.setOnClickListener(this);

    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        inputValidation = new InputValidation(activity);
        registrationDao = new RegistrationDao(activity);
        donor = new Donor();

    }


    /**
     * This implemented method is to listen the click on view
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.appCompatButtonRegister:
                postDataToSQLite();
                break;

            case R.id.appCompatTextViewLoginLink:
                finish();
                break;
        }
    }

    /**
     * This method is to validate the input text fields and post data to SQLite
     */
    private void postDataToSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextName, textInputLayoutName, getString(R.string.error_message_name))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPhoneNumber, textInputLayoutNumber, getString(R.string.error_message_phoneNumber))) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPassword, textInputLayoutPassword, getString(R.string.error_message_password))) {
            return;
        }
        if (!inputValidation.isInputEditTextMatches(textInputEditTextPassword, textInputEditTextConfirmPassword,
                textInputLayoutConfirmPassword, getString(R.string.error_password_match))) {
            return;
        }


        if (!registrationDao.checkDonor(textInputEditTextEmail.getText().toString().trim())) {

            donor.setName(textInputEditTextName.getText().toString().trim());
            donor.setPhNum(textInputEditTextPhoneNumber.getText().toString().trim());
            donor.seteMail(textInputEditTextEmail.getText().toString().trim());
            donor.setPwd(textInputEditTextPassword.getText().toString().trim());
            donor.setBloodGroup(bloodGrp.getSelectedItem().toString().trim());

            registrationDao.addDetails(donor);
            jsonConsume(apiURL);

        } else {
            // Snack Bar to show error message that record already exists
            Snackbar.make(nestedScrollView, getString(R.string.error_email_exists), Snackbar.LENGTH_LONG).show();
        }

            //Post Mapping
            JsonObject jsonObject=new JsonObject();
//            jsonObject.addProperty("");
            jsonObject.addProperty("name",textInputEditTextName.getText().toString().trim());
            jsonObject.addProperty("phNum",textInputEditTextPhoneNumber.getText().toString().trim());
            jsonObject.addProperty("eMail",textInputEditTextEmail.getText().toString().trim());
            jsonObject.addProperty("pwd",textInputEditTextPassword.getText().toString().trim());
            jsonObject.addProperty("rePwd",textInputEditTextPassword.getText().toString().trim());
            jsonObject.addProperty("bloodGroup",bloodGrp.getSelectedItem().toString().trim());
            JsonObject loc=new JsonObject();
            loc.addProperty("donorLat",12);
            loc.addProperty("donorLong",23);

            Ion.with(getApplicationContext()).load(apiURL).setJsonObjectBody(jsonObject).asJsonObject().setCallback(new FutureCallback<JsonObject>() {
                @Override
                public void onCompleted(Exception e, JsonObject result) {
                    Log.i(TAG,"Registration complete");
                }
            });


        // Snack Bar to show success message that record saved successfully
        Snackbar.make(nestedScrollView, getString(R.string.success_message), Snackbar.LENGTH_LONG).show();
        startActivity(new Intent(getApplicationContext(), Main2Activity.class));
        emptyInputEditText();


    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        textInputEditTextName.setText(null);
        textInputEditTextEmail.setText(null);
        textInputEditTextPassword.setText(null);
        textInputEditTextConfirmPassword.setText(null);
    }


    private void jsonConsume(final String apiURL) {

        class MyAsyncTasks extends AsyncTask<Void, Void, Void> {
//            ProgressDialog progressDialog=new ProgressDialog(RegistrationActiviity.this);

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog = new ProgressDialog(RegistrationActiviity.this);
                progressDialog.setMessage("Registering Donor");
                progressDialog.setCanceledOnTouchOutside(true);
                progressDialog.show();
            }

            @Override
            protected Void doInBackground(Void... voids) {
                insertToServer();
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                progressDialog.dismiss();

            }
        }
        MyAsyncTasks getJSON = new MyAsyncTasks();
        getJSON.execute();
    }

    private void insertToServer() {
        HttpClient httpclient=new DefaultHttpClient();
        HttpPost httppost=new HttpPost(apiURL);
        try {
            List<NameValuePair> namevaluepair=new ArrayList<NameValuePair>(6);
            namevaluepair.add(new BasicNameValuePair("name", textInputEditTextName.getText().toString().trim()));
            Log.d("name",textInputEditTextName.getText().toString().trim());
            namevaluepair.add(new BasicNameValuePair("phNum", textInputEditTextPhoneNumber.getText().toString().trim()));
            Log.d("phNum",textInputEditTextPhoneNumber.getText().toString().trim());
            namevaluepair.add(new BasicNameValuePair("eMail",textInputEditTextEmail.getText().toString().trim()));
            Log.d("eMail",textInputEditTextEmail.getText().toString().trim());
            namevaluepair.add(new BasicNameValuePair("pwd",textInputEditTextPassword.getText().toString().trim()));
            Log.d("pwd",textInputEditTextPassword.getText().toString().trim());
            namevaluepair.add(new BasicNameValuePair("rePwd",textInputEditTextPassword.getText().toString().trim()));
            Log.d("pwd",textInputEditTextPassword.getText().toString().trim());
            namevaluepair.add(new BasicNameValuePair("bloodGroup",bloodGrp.getSelectedItem().toString().trim()));
            Log.d("bloodGroup",bloodGrp.getSelectedItem().toString().trim());


            httppost.setEntity(new UrlEncodedFormEntity(namevaluepair));
            HttpResponse httpresponse=httpclient.execute(httppost);
            int status=httpresponse.getStatusLine().getStatusCode();
            Log.d("status",status+"");
        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}
